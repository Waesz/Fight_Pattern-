Fight Pattern

C'est une jeu où vous faites combattre un groupe de joueur contre un groupe de personnage non joueur(PNJ). Ils se combattent avec des arles.